let hours_worked = (35, 32, 32)
